import { Color } from './color.js';

export class Material {
    constructor() { }
    getColorAt = point => Color.Grey;
}