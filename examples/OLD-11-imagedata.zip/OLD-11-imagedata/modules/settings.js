export const THRESHOLD = 0.000001;
export const MAX_DEPTH = 8;
