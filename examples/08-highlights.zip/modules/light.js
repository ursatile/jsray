export class Light {
    constructor(position, color) {
        this.position = position;
        this.color = color;
    }
}