export class Greeter {
    constructor(name) {
        this.name = name;
    }
    greet = () => `Hello, ${this.name}!`;
}
